# Exercício 1
## Filtrar palavras terminadas em A

Escrever um código que recebe uma lista de strings e retorna todas as strings dessa lista que terminam com a letra "a" (sem diferenciação de maiúsculas e minúsculas)

### Instruções
- Abra o arquivo index.ts
- Inclua seu código na região assinalada
- Execute o exercício conforme instruções do README da pasta anterior
- Verifique se o resultado coincide com os testes já implementados
- Crie novos testes se quiser
- Todos os códigos **devem tentar prever erros** de inputs vazios, nulos, ou fora do contexto do problema (e isso será bem visto!)

##### Em caso de dúvida sobre o enunciado, consulte os exemplos no código!



**Boa sorte!**


